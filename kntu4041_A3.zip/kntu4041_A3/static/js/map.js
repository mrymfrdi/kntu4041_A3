const wmsUrl = window.GEOSERVER_WMS_URL;
const layerName = window.GEOSERVER_LAYER_NAME;

const osm = new ol.layer.Tile({
  source: new ol.source.OSM()
});

const wmsLayer = new ol.layer.Tile({
  source: new ol.source.TileWMS({
    url: wmsUrl,
    params: {
      'LAYERS': layerName,
      'TILED': true
    },
    serverType: 'geoserver',
    crossOrigin: 'anonymous'
  })
});

const view = new ol.View({
  center: ol.proj.fromLonLat([51.3890, 35.6892]), 
  zoom: 10
});

const map = new ol.Map({
  target: 'map',
  layers: [osm, wmsLayer],
  view
});

const infoContent = document.getElementById('infoContent');

function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderProperties(props) {
  const keys = Object.keys(props || {}).filter(k => k !== 'geometry');
  if (!keys.length) return "<div class='muted'>No attributes found.</div>";

  let html = "<table class='tbl'><thead><tr><th>Field</th><th>Value</th></tr></thead><tbody>";
  for (const k of keys) {
    html += `<tr><td>${escapeHtml(k)}</td><td>${escapeHtml(props[k])}</td></tr>`;
  }
  html += "</tbody></table>";
  return html;
}

map.on('singleclick', function (evt) {
  const viewResolution = view.getResolution();

  const url = wmsLayer.getSource().getFeatureInfoUrl(
    evt.coordinate,
    viewResolution,
    view.getProjection(),
    {
      'INFO_FORMAT': 'application/json',
      'FEATURE_COUNT': 5
    }
  );

  if (!url) {
    infoContent.innerHTML = "<div class='muted'>No feature info URL.</div>";
    return;
  }

  infoContent.innerHTML = "<div class='muted'>Loading…</div>";

  fetch(url)
    .then(r => r.json())
    .then(data => {
      if (!data || !data.features || !data.features.length) {
        infoContent.innerHTML = "<div class='muted'>No feature found at clicked location.</div>";
        return;
      }

    
      const f = data.features[0];
      infoContent.innerHTML = renderProperties(f.properties);
    })
    .catch(err => {
      console.error(err);
      infoContent.innerHTML = "<div class='msg error'>GetFeatureInfo failed. Check GeoServer CORS / layer name.</div>";
    });
});

